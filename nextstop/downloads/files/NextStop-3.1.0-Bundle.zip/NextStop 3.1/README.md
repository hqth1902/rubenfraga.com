# NextStop 3.1.0

NextStop is a personal Swiss departure board with an independent, battery-capable ESP32-C6 and a universal Mac configuration app. The board fetches timetable data itself; the Mac does not need to stay open or nearby. The app and local browser interface support German and English. Bus and train badges stay coloured in the app; the physical display is monochrome.

## Finished files

- `01 Applications/Mac`: the Mac DMG and ZIP, for Intel and Apple Silicon, macOS 13 or newer.
- `01 Applications/Windows and Browser`: a launcher for the board's own browser interface. There is no Windows executable to install.
- `02 ESP32`: a compiled factory image for **DFRobot FireBeetle 2 ESP32-C6 (DFR1075, 4 MB)** and the flashing and wiring guides.
- `03 Updates`: a signed `.nextstop` firmware update. Factory images and OTA updates serve different purposes.
- `04 Previews and Checks`: software verification results. These do not replace a physical hardware test.
- `05 Distribution`: the finished bundle to give someone or attach to a GitHub Release.
- `06 Website`: the ready website overlay and integration guide for `rubenfraga.com/nextstop/`.

Use `GETTING-STARTED.md`, `02 ESP32/FLASH-ESP32.md`, and `HARDWARE.md` in that order. The old Raspberry Pi service, installers and release files are no longer part of this version. ESP32 firmware cannot be installed on a Raspberry Pi, and Pi update ZIPs cannot update the ESP32.

## Hardware and timing

The prepared target is the Waveshare 7.5-inch black/white V2 display, **800 × 480**, SKU **13504**, connected through its driver HAT's eight-pin SPI cable. Check the actual display/controller revision when it arrives; Waveshare reused the product name across revisions. An untested panel is not automatically covered by this firmware.

Battery mode wakes every five minutes by default, fetches data, refreshes if appropriate, and returns to deep sleep. The e-ink image remains visible. Wi-Fi and configuration access are unavailable during deep sleep. A physical setup button on GPIO6 opens a ten-minute configuration window. Continuous mode keeps the board accessible and can query data every 30 seconds. The actual display refresh interval is independently limited to at least 180 seconds, following Waveshare's guidance. A fixed battery runtime has not been measured.

Partial refresh depends on the verified panel revision and retained controller state. Waking from deep sleep requires a full refresh when the image changes; unchanged images are skipped. Continuous mode can use partial refresh on compatible hardware, with periodic full refreshes to clear ghosting. Do not assume that partial refresh survives display power-off or hibernation.

## Data

The defaults are Winterthur HB trains calling later at Zürich Altstetten, and Winterthur Hinterwiesli bus 2 towards Winterthur Seen. The board filters direct departures; it does not plan transfers. Available delays, platform changes and cancellations are displayed. Missing real-time information is labelled as timetable data rather than confirmed punctuality. A service disappearing from a response is not classified as cancelled.

Choose **1–12 connections per configured stop entry**. The selected number is not shared between entries: choosing five with the defaults shows up to five trains and five buses. Line and direction filters still apply, and the provider may return fewer matching departures. The Mac and browser show every entry together. If the entries and their headings do not all fit on the physical display, they appear on numbered pages that advance at the next permitted screen update. Two entries with five departures each fit on one page; larger configurations may need several pages.

The free Transport API needs no key. The optional official OJP interface requires your own API key from opentransportdata.swiss. Provider coverage determines which real-time notices are available. The board cannot guarantee immediate disruption notices, particularly while sleeping or waiting for the next permitted screen refresh.

## Configuration and updates

First-time setup uses a password-protected local Wi-Fi network and a setup page. The e-ink screen displays the network details and setup QR code. On the home network, the Mac app or browser pairs using the displayed six-digit code. Device control uses authenticated HTTP on the local network; provider access uses certificate-verified HTTPS. Use a trusted home network. Never expose the configuration server to the internet.

Firmware updates are accepted only if their Ed25519 signature, hardware identity, version, size and SHA-256 hash match. The signing key stays in `Internal/SigningKeys` and is never part of a shareable bundle. A firmware update is written to the inactive application partition; a transfer failure leaves the running partition unchanged. Software validation cannot establish automatic recovery from every hardware/boot fault; USB re-flashing is the recovery method.

The Mac checks `https://rubenfraga.com/nextstop/updates/mac/appcast.xml` by default. New boards use `https://rubenfraga.com/nextstop/updates/esp32/latest.nextstop`; saved custom channels remain unchanged and automatic device installation stays off until enabled. The addresses become available when the website package is published through GitHub Pages. Local signed files can still be installed through the app or browser while the board is awake. This Mac build is locally signed and **not Apple-notarized**.

The setup screen includes a permanent **App & help** QR to the website, alongside the local Wi-Fi/configuration QR codes. The browser controls the board directly and needs no installation. The public website is an entry point and does not send Wi-Fi credentials or pairing tokens to the publisher.

## Development

Source is in `Development`, private keys and build tools in `Internal`. Build the device with PlatformIO using `Development/ESP32/platformio.ini`, the app with `Internal/Tools/build.sh`, then package with `package-mac.sh`, `package-release.py`, and `package-share.py`. Dependencies and platform versions are pinned in the build configuration. The browser assets are embedded into the firmware so OTA updates replace the UI together with the device code.

The factory image contains no personal Wi-Fi credentials, pairing token or provider key. A factory reset or erasing flash removes local settings. Do not confuse an ordinary app reset with erasing flash during a gift handover. See `THIRD-PARTY-NOTICES.md` for component licences.
