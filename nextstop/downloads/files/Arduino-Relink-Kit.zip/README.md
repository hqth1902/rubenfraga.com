# ESP32 library source and relinking kit

This kit supplies the unmodified Arduino-ESP32 3.3.7 framework source and the NextStop firmware source needed to rebuild/relink the device with modified LGPL libraries. Third-party licence notices remain in each component. Private signing keys and saved device settings are excluded. The separate Mac application source is not included.

The NextStop firmware source supplied here may be modified and rebuilt for use with modified libraries. Reverse engineering necessary to debug those library modifications is permitted. This permission does not remove the existing third-party licences or grant rights in the separate Mac application.

Install PlatformIO with Python3.12 or newer. Project layout is Development/ESP32 and Development/UI. Run the environment firebeetle2-c6 from Development/ESP32. prepare_ui.py embeds the included browser UI. PlatformIO downloads the pinned compiler and SDK described in platformio.ini. Replace the PlatformIO framework-arduinoespressif32 package with the included modified library source before rebuilding. Do not let a clean dependency download overwrite your modified library.

No publisher signing key is needed to compile or USB-flash a modified firmware. Replace the public Ed25519 key in ota.cpp and update-public-key.pem with your own identity if you want your own OTA channel. Retain its matching private key locally. USB flashing remains unrestricted; use the factory-image instructions and standard esptool commands to install modified builds.

Upstream framework: https://github.com/espressif/arduino-esp32/tree/3.3.7
The LGPL2.1text is included as LICENSE.md. Other package components retain their notices. The framework source has not been modified in this kit. Unused GNU FreeFont/FreeSans bitmap fonts and examples are excluded from the AdafruitGFX source copy; NextStop uses the included OFL Noto-derived fonts instead.
